﻿using System;
using System.IO;

namespace ellenorzes
{
  class Ido
  {
    public int Ora { get; set; }
    public int Perc { get; set; }
    public double Mp { get; set; }
    public double Time()
    {
      return (double)Ora + (double)Perc / 60 + Mp / 3600; 
    }
    public Ido(int ora = 0, int perc = 0, int mp = 0, int ezred = 0)
    {
      Ora = ora;
      Perc = perc;
      Mp = (double)mp + (double)ezred / 1000;
    }
  }
  class Meres
  {
    public string Rendszam { get; set; }
    public Ido Be { get; set; }
    public Ido Ki { get; set; }
    public double TimeSpan()
    {
      return Ki.Time() - Be.Time();
    }
    public double V()
    {
      return 10.0 / (Ki.Time() - Be.Time());
      //return 36000.0 / ((double)Ki.Ora*3600 + (double)Ki.Perc *60 + Ki.Mp - ((double)Be.Ora * 3600 + (double)Be.Perc * 60 + Be.Mp));
      /*Ez pontosabb, de még itt is van a központi megoldáshoz képest másfele kerekítés*/
    }

    public Meres(string bejegyzes)
    {
      string[] adatok = bejegyzes.Split(' ');
      Rendszam = adatok[0];
      Be = new Ido(int.Parse(adatok[1]), int.Parse(adatok[2]), int.Parse(adatok[3]), int.Parse(adatok[4]));
      Ki = new Ido(int.Parse(adatok[5]), int.Parse(adatok[6]), int.Parse(adatok[7]), int.Parse(adatok[8]));
    }
  }

  class Program
  {
    static void Main()
    {
      Meres[] meresek = new Meres[1000];
      int N = Beolvas("meresek.txt", meresek);
      Console.WriteLine($"2. feladat\nA mérés során {N} jármű adatait rögzítették.");
      Console.WriteLine($"3. feladat\n9 óra előtt {F3_Koraidb(meresek,N)} jármű haladt el a végponti mérőnél.");
      Console.Write($"4.feladat\nAdjon meg egy óra és perc értéket! ");
      string[] t = Console.ReadLine().Split(' ');      
      (int be, double suru)= F4_Belepdb(meresek, N, int.Parse(t[0]), int.Parse(t[1]));
      Console.WriteLine($"a.\tA kezdeti méréspontnál elhaladt járművek száma: {be}");
      Console.WriteLine($"b.\tA forgalomsűrűség: {suru:F1}");
      int maxind = F5_MinTime(meresek, N);
      Console.WriteLine($"5.feladat\nA legnagyobb sebességgel haladó jármű\n\trendszáma: {meresek[maxind].Rendszam}");
      Console.WriteLine($"\tátlagsebessége: {(int)(10/meresek[maxind].TimeSpan())} km/h");
      Console.WriteLine($"\táltal lehagyott járművek száma: {F5_Lehagyott(meresek, maxind)}");
      Console.WriteLine($"6. feladat\nA járművek {F6_Gyorsarany(meresek, N, 90):P2}-a volt gyorshajtó.");
      F7_Buntetes(meresek, N);
      Console.WriteLine("A fájl elkészült");
    }

    private static void F7_Buntetes(Meres[] m, int n)
    {
      StreamWriter sw = new("buntetes.txt");
      for (int i = 0; i < n; i++)
      {
        int bunti = 0;
        if (m[i].V() > 151 )
          bunti = 200000;
        else if (m[i].V() > 136)
          bunti = 60000;
        else if (m[i].V() > 121)
          bunti = 45000;
        else if (m[i].V() > 104)
          bunti = 30000;

        if (bunti > 0)
          sw.WriteLine($"{m[i].Rendszam} {(int)m[i].V()} km/h {bunti} Ft");
      }
      sw.Close();
    }
    
    private static double F6_Gyorsarany(Meres[] m, int n, int v)
    {
      int db = 0;
      for (int i = 0; i < n; i++)
        if (m[i].V() > v)
          db++;
      return (double)db / n;
    }

    private static int F5_Lehagyott(Meres[] m, int maxind)
    {
      int db = 0;
      for (int i = 0; i < maxind ; i++)
        if (m[i].Ki.Time() > m[maxind].Ki.Time())
          db++;
      return db;
    }

    private static int F5_MinTime(Meres[] m, int n)
    {
      int ez = 0;
      for (int i = 0; i < n; i++)
        if (m[i].TimeSpan() < m[ez].TimeSpan())
          ez = i;
      return ez;
    }

    private static (int, double) F4_Belepdb(Meres[] m, int n, int ora, int perc)
    {
      int be = 0;
      int bent = 0;
      for (int i = 0; i < n; i++)
      {
        if (m[i].Be.Ora == ora && m[i].Be.Perc == perc)
          be++;
        bool bement = (m[i].Be.Ora < ora) || (m[i].Be.Ora == ora && m[i].Be.Perc <= perc);
        bool kiment = (m[i].Ki.Ora < ora) || (m[i].Ki.Ora == ora && m[i].Ki.Perc < perc);
        if (bement && !kiment)
          bent++;
      }

      return (be, (double)bent/10);
    }

    private static int F3_Koraidb(Meres[] m, int n)
    {
      int db = 0;
      for (int i = 0; i < n; i++)
        if (m[i].Ki.Ora < 9)
          db++;
      return db;
    }

    private static int Beolvas(string v, Meres[] m)
    {
      int db;
      StreamReader sr = new(v);
      for(db = 0; !sr.EndOfStream; db++)
        m[db] = new Meres(sr.ReadLine());
      sr.Close();
      return db;
    }
  }
}
