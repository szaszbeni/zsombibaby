﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace cegesauto
{
    class Foglalas
    {
        public string rendszam;
        public int user;
        public int kinap;
        public string kiido;
        public int kikm;
        public int benap;
        public string beido;
        public int bekm;
        public int menet;

        public Foglalas(string rsz = "-", int u = 0, int kin = 0, string kit = "0:0", int kik = 0)
        {
            rendszam = rsz;
            user = u;
            kinap = kin;
            kiido = kit;
            kikm = kik;

            benap = 0;
            beido = "0:0";
            bekm = kikm;
            menet = 0;
        }
    }
    class Program
    {
        static List<Foglalas> Naplo = new List<Foglalas>();

        static void f1_input()
        {
            StreamReader fin = new StreamReader("autok.txt");
            while (!fin.EndOfStream)
            {
                string[] adatsor = fin.ReadLine().Split(' '); 
                int nap = int.Parse(adatsor[0]);
                string ido = adatsor[1];
                string rsz = adatsor[2];
                int u = int.Parse(adatsor[3]);
                int km = int.Parse(adatsor[4]);
                int tipus = int.Parse(adatsor[5]);
                if (tipus == 0)
                {
                    Naplo.Add(new Foglalas(rsz, u, nap, ido, km ));
                }
                else
                {
                    int ez = Naplo.Count - 1;
                    while (Naplo[ez].rendszam != rsz) ez--;
                    Naplo[ez].benap = nap;
                    Naplo[ez].bekm = km;
                    Naplo[ez].beido = ido;
                    Naplo[ez].menet = Naplo[ez].bekm - Naplo[ez].kikm;
                }
            }
            fin.Close();
        }

        static void f3_napiforgalom(int n)
        {
            int nap;
            Console.Write("Nap: ");
            nap = int.Parse(Console.ReadLine());
            Console.WriteLine("Forgalom a {0}. napon:", nap);
            /*A tavozas sorrendjeben*/
            for (int i = 0; i < n; ++i)
            {
                if (Naplo[i].kinap == nap)
                    Console.WriteLine("{0} {1} {2} ki", Naplo[i].kiido, Naplo[i].rendszam, Naplo[i].user);
                if (Naplo[i].benap == nap)
                    Console.WriteLine("{0} {1} {2} be", Naplo[i].beido, Naplo[i].rendszam, Naplo[i].user);
            }

        }
        static int f4_kintlevok()
        {
            int db = 0;
            foreach (var a in Naplo)
                if (a.benap == 0)
                    db++;
            return db;
        }

        static int f5_id(string rendszam)
        {
            return rendszam[5] - 48;
        }

        static void f5_km()
        {
            int[] osszes = new int[10];
            for(int i = 0; i < 10; i++) osszes[i] = 0;
            foreach (var a in Naplo)
                osszes[f5_id(a.rendszam)] += a.menet;
            for (int ez = 0; ez < 10; ++ez)
                Console.WriteLine("CEG30{0} {1} km", ez, osszes[ez]);
        }

        static void f6_maxtav()
        {
            var max = Naplo[0];
            foreach (var a in Naplo)
                if (a.menet > max.menet)
                {
                    max = a;
                }
            Console.WriteLine("Leghosszabb ut: {0} km, szemely: {1}", max.menet, max.user);
        }

        static void f7_menetlevel()
        {
            string rsz;
            Console.Write("Rendaszam: ");
            rsz = Console.ReadLine();
            StreamWriter fout = new StreamWriter(rsz + "menetlevel.txt");
            foreach (var a in Naplo)
                if (a.rendszam == rsz)
                {
                    fout.Write(a.user + "\t");
                    fout.Write("{0,2}. {1}\t{2,6} km\t", a.kinap, a.kiido, a.kikm);
                    if (a.kikm < a.bekm)
                        fout.WriteLine("{0,2}. {1}\t{2,6} km\t", a.benap, a.beido, a.bekm);
                }
            fout.Close();
        }


        static void Main(string[] args)
        {
            f1_input();
            int n = Naplo.Count();
            Console.WriteLine();
            Console.WriteLine("2. feladat");
            Console.WriteLine("{0}. nap rendszam: {1}", Naplo[n - 1].kinap, Naplo[n - 1].rendszam);

            Console.WriteLine();
            Console.WriteLine("3. feladat");
            f3_napiforgalom(n);

            Console.WriteLine();
            Console.WriteLine("4. feladat");
            Console.WriteLine("A honap vegen {0} autot nem hoztak vissza.", f4_kintlevok());

            Console.WriteLine();
            Console.WriteLine("5. feladat");
            f5_km();

            Console.WriteLine();
            Console.WriteLine("6. feladat");
            f6_maxtav();

            Console.WriteLine();
            Console.WriteLine("7. feladat");
            f7_menetlevel();

            Console.WriteLine("Menetlevel kesz.");
        }
    }
}
